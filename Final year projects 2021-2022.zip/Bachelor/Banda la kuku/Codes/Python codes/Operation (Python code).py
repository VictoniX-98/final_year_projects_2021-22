import cv2 as cv
import time
import serial
import keyboard

# Definition of useful variables
port = 'COM14'          # USB is connection is connected to this port number
boudrate = 9600    # communicate is done at this speed of beatrate
is_sensed = True
payload = ''

ArduinoSerial = serial.Serial(port, boudrate)
video = cv.VideoCapture(0) # Capture video at camera number

def receive_data():

    while True:
        print("Wait for detection response")

        data = ArduinoSerial.readline()
        payload = str(data.decode('Ascii'))

        print(data)
        print(payload)

        time.sleep(1)

        if(payload == "check"):
            break

        if keyboard.is_pressed('c'):
            break


while True:  
    receive_data()
    
    isCaptured, frame = video.read()
    gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

    chicken = cv.CascadeClassifier(r'C:\Users\VictoniX\OneDrive\VicTech Data\Projects\Banda la kuku\Image classfier\classifier\cascade.xml') #Chicken Cascade classifier comes here
    detected_chicken = chicken.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=5)
     
    cv.imshow('Video screen', frame)
    time.sleep(3)

    if(len(detected_chicken) > 0):
        print('Chicken detected')
        ArduinoSerial.write('detected'.encode('Ascii'))
    else:
        print('No chicken detected')
        ArduinoSerial.write('nothing'.encode('Ascii'))

    cv.destroyAllWindows()
    video.release()