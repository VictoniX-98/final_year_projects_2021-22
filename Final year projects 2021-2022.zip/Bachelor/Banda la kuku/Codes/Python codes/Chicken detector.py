# from tkinter.ttk import Frame
import cv2 as cv

video = cv.VideoCapture(0)

while True:
    isCaptured, frame = video.read()
    gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY) #  Convert the video to gray scale

    chicken = cv.CascadeClassifier(r'C:\Users\VictoniX\OneDrive\VicTech Data\Projects\Banda la kuku\Image classfier\classifier\cascade.xml')
    detected_chicken = chicken.detectMultiScale(gray_frame, scaleFactor=2.5, minNeighbors=3)

    
    if(len(detected_chicken) > 0):
        print('Chicken detected')
    else:
        print('No chicken detected')
    

    for (x, y, w, h) in detected_chicken:
        cv.rectangle(frame, (x,y), (x+w, y+h), (0,255,0), 2)

    cv.imshow('Video Screen', frame)

    if cv.waitKey(1) & 0xff==ord('c'):
        break

video.release()
cv.destroyAllWindows()