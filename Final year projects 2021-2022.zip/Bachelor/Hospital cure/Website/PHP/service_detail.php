<?php
include('db_connection.php');

$sql = 'SELECT * FROM service_details';
$query = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service details</title>
    <style>
        body{
            font-family: sans-serif;
        }

        table{
            border-collapse: collapse;
            width: 100%;
        }

        td, th {
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            padding: 9px;
        }

        th{
            background-color: rgb(33, 142, 33);
            font-size: 30px;
            color: white;
            height: 50px;
        }

        tr:nth-child(odd){
            background-color: rgb(224, 227, 235);
        }

        tr:hover{
            background-color: lightgreen;
        }
    </style>
</head>
<body>
    <center>
        <table>
            <h1>SERVICE <small style="color: rgb(114, 114, 255);">Details</small></h1>
            <tr>
                <th>Ward No:</th>
                <th>Bed No:</th>
                <th>Request time</th>
                <th>Response time</th>
                <th>Date</th>
            </tr>

            <?php
            if($query){
                while($row = mysqli_fetch_assoc($query)){
                    $ward = $row['ward_no'];
                    $bed = $row['bed_no'];
                    $request = $row['request_time'];
                    $response = $row['response_time'];
                    $date = $row['date'];

                    echo'
                        <tr>
                            <td>'.$ward.'</td>
                            <td>'.$bed.'</td>
                            <td>'.$request.'</td>
                            <td>'.$response.'</td>
                            <td>'.$date.'</td>
                        </tr>
                    ';
                }
            }
            ?>
        </table>
    </center>
</body>
</html>