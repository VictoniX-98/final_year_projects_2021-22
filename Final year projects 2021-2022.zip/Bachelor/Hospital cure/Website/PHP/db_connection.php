<?php
     $host_name = "localhost";
     $db_user = "root";
     $password = "";
     $db_name = "hospital_cure";
     
     $conn = mysqli_connect($host_name, $db_user, $password, $db_name);

     if(!$conn){
          die("Fail to connect to Database \n" ."Error: ". mysqli_connect_error());
     }
?>