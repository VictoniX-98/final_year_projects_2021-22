<?php
include('db_connection.php');

if(isset($_GET['ward_no']) && isset($_GET['bed_no'])){
    $ward = $_GET['ward_no'];
    $bed = $_GET['bed_no'];

    $sql = 'INSERT INTO service_details (`ward_no`, `bed_no`, `request_time`, `date`) VALUES (\''.$ward.'\',\''.$bed.'\',curtime(),curdate())';
    $query = mysqli_query($conn, $sql);

    if($query) echo'SUCCESS';
    else echo'FAIL';
}else echo'No data to insert';

