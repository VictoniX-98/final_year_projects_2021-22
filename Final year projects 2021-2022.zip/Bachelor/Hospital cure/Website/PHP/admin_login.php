<?php
include('db_connection.php');

if((isset($_POST['username']) || isset($_POST['password'])) && ($_POST['username'] != "" || $_POST['password'] != "")){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin_credential";
    $query = mysqli_query($conn, $sql);
    
    if($query){
        while($row = mysqli_fetch_assoc($query)){
            $user = $row['username'];
            $pass = $row['password'];
        }

        if($user == $username && $pass == $password){
            echo'
                <iframe src="../HTML/admin_page.html" frameborder="0" style="height: 100vh; width: 100vw;"></iframe>
            ';
        }else{
            echo'
                <center>
                    <h1> <big style="color: red;">Error:</big> Wrong informations</h1>
                    </br>
                    <a style="text-decoration: none; color: blue; font-weight: bold;" href="../HTML/admin_login.html">Back</a>
                </center>
            ';
        }
    }else{
        echo'
            <center>
                <h1> <big style="color: red;">Error:</big> Database connection fail</h1>
                </br>
                <a style="text-decoration: none; color: blue; font-weight: bold;" href="../HTML/admin_login.html">Back</a>
            </center>
        ';
    }
}else{
    echo'
        <center>
            <h1> <big style="color: red;">Error:</big> Please insert login credentials</h1>
            </br>
            <a style="text-decoration: none; color: blue; font-weight: bold;" href="../HTML/admin_login.html">Back</a>
        </center>
    ';
}