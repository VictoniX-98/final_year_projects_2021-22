<?php
include('db_connection.php');

$sql = 'SELECT * FROM current_contacts';
$query = mysqli_query($conn, $sql);

if($query){
    while($row = mysqli_fetch_assoc($query)){
        $status = $row['status'];
        $phone1 = $row['phone1'];
        $phone2 = $row['phone2'];
    }

    if($status == "new"){
        $sql = 'UPDATE current_contacts SET status=\'old\'';
        $query = mysqli_query($conn, $sql);

        if($query){
            echo $phone1.' & '.$phone2;
        }else return;
    }
}else echo'Database error';