<?php
include('db_connection.php');

if((isset($_POST['personnel1_phone']) || isset($_POST['personnel2_phone'])) && ($_POST['personnel1_phone'] != "" || $_POST['personnel2_phone'] != "")){
    $phone1 = $_POST['personnel1_phone'];
    $phone2 = $_POST['personnel2_phone'];

    $sql = 'UPDATE current_contacts SET status=\'new\', phone1=\''.$phone1.'\', phone2=\''.$phone2.'\'';
    $query = mysqli_query($conn, $sql);

    if($query){
        echo'
            <center>
                <h1 style="color: rgb(33, 142, 33);">DONE</h1>
                </br>
                <a style="text-decoration: none; color: blue; font-weight: bold;" href="../index.html">Back</a>
            </center>
        ';
    }

}else{
    echo'
        <center>
            <h1> <big style="color: red;">Error:</big> Please insert contacts</h1>
            </br>
            <a style="text-decoration: none; color: blue; font-weight: bold;" href="../index.html">Back</a>
        </center>
    ';
}