<?php
include('db_connection.php');


$sql = 'SELECT * FROM service_details';
$query = mysqli_query($conn, $sql);

if($query) while($row = mysqli_fetch_assoc($query)) $id = $row['id'];
else echo'Database error';

$sql = 'UPDATE service_details SET response_time = curtime() WHERE id=\''.$id.'\'';
$query = mysqli_query($conn, $sql);

if($query) echo'SUCCESS';
else echo'FAIL';