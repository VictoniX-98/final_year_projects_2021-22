<?php
include('db_connection.php');

if((isset($_POST['username']) && isset($_POST['password'])) && ($_POST['username'] != "" || $_POST['password'] != "")){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM credential";
    $query = mysqli_query($conn, $sql);
    
    if($query){
        while($row = mysqli_fetch_assoc($query)){
            $user = $row['username'];
            $pass = $row['password'];
        }

        if($user == $username && $pass == $password){
            echo'
                <!DOCTYPE html>
                <html lang="en">
                    <head>
                        <meta charset="UTF-8">
                        <meta http-equiv="X-UA-Compatible" content="IE=edge">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <title>Results</title>
            
                        <style>
                            body{
                                font-family: sans-serif;
                                padding: 10px;
                            }
                
                            .heading{
                                font-size: 40px;
                            }
            
                            #runner1{
                                height: 40px;
                                margin-left: 10px;
                            }
            
                            #runner3_1{
                                float: left;
                                height: 80vh;
                                margin-left: 100px;
                            }
            
                            #runner3_2{
                                float: right;
                                height: 80vh;
                                margin-right: 100px;
                                transform: scaleX(-1);
                            }
                        </style>
                    </head>
                    <body>
                        <center>
                            <a style="text-decoration: none; color: rgb(47, 47, 151); font-weight: bold; float: left;" href="../index.html">Back</a>
                            <h1 class="heading"><b style="color: rgb(255, 111, 0);">TIMING</b> <i style="color: orange;">SYSTEM</i> <small><small>for a </small><i style="color: rgb(35, 35, 200);">Runner</i></small><img id="runner1" src="../images/runner1.jpeg" alt="Runner1-image"></h1>
                            <img id="runner3_1" src="../images/runner3.png" alt="Left-runner-image">
                            <iframe src="table.php" frameborder="0" height="600" width="800"></iframe>
                            <img id="runner3_2" src="../images/runner3.png" alt="Right-runner-image">
                        </center>
                    </body>
                </html>
            
            ';
        }else{
            echo'
                <center>
                    <h1> <big style="color: red;">Error:</big> Wrong informations</h1>
                    </br>
                    <a style="text-decoration: none; color: blue; font-weight: bold;" href="../index.html">Back</a>
                </center>
            ';
        }
    }else{
        echo'
            <center>
                <h1> <big style="color: red;">Error:</big> Database connection fail</h1>
                </br>
                <a style="text-decoration: none; color: blue; font-weight: bold;" href="../index.html">Back</a>
            </center>
        ';
    }
}else{
    echo'
        <center>
            <h1> <big style="color: red;">Error:</big> Please insert login credentials</h1>
            </br>
            <a style="text-decoration: none; color: blue; font-weight: bold;" href="../index.html">Back</a>
        </center>
    ';
}
?>