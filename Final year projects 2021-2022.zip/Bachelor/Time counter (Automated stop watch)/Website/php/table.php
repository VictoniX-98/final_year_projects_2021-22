<?php
include('db_connection.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Table of results</title>

        <style>
            body{
                font-family: sans-serif;
            }

             table{
                border-collapse: collapse;
                width: 100%;
            }

            td, th {
                text-align: center;
                font-size: 20px;
                font-weight: bold;
                padding: 9px;
            }

            th{
                background-color: rgb(47, 47, 151);
                font-size: 30px;
                color: white;
                height: 50px;
            }

            tr:nth-child(odd){
                background-color: rgb(224, 227, 235);
            }

            tr:hover{
                background-color: orange;
            }
        </style>
    </head>
    <body>
        <center>
            <table>
                <h2>TABLE OF RESULTS</h2>

                <tr>
                    <th>Player-1 Time</th>
                    <th>Player-2 Time</th>
                    <th>Date</th>
                    <th>Time</th>
                </tr>

<?php
$sql = 'SELECT * FROM results';
$query = mysqli_query($conn, $sql);

if($query){
    while($row = mysqli_fetch_assoc($query)){
        $player1_time = $row['player1_time'];
        $player2_time = $row['player2_time'];
        $date = $row['date'];
        $time = $row['time'];

        echo'
            <tr>
                <td>'.$player1_time.'</td>
                <td>'.$player2_time.'</td>
                <td>'.$date.'</td>
                <td>'.$time.'<td>
            </tr>
        ';
    }


}else{
    echo'
        <center>
            <h1> <big style="color: red;">Error:</big> Database connection fail</h1>
            </br>
            <a style="text-decoration: none; color: blue; font-weight: bold;" href="../HTML/admin_login.html">Back</a>
         </center>
    ';
}

?>
   
            </table>  
        </center>
    </body>
</html>