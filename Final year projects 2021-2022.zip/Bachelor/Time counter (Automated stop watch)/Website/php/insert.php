<?php
include('db_connection.php');

if(isset($_GET['time1']) || isset($_GET['time2'])){
    $time1 = $_GET['time1'];
    $time2 = $_GET['time2'];

    $sql = 'INSERT INTO results (player1_time, player2_time, date, time) VALUES (\''.$time1.'\',\''.$time2.'\',curdate(), curtime())';
    $query = mysqli_query($conn, $sql);

    if($query) echo'SUCCESS';
    else echo'FAIL';
}else echo'No data to insert';